
# Create Restore Point Script (Run as Administrator)
Checkpoint-Computer -Description "Pre-Hardening Restore Point" -RestorePointType "MODIFY_SETTINGS"
